describe('Registro de Usuario', () => {
  it('Registra un nuevo usuario con datos válidos', () => {
    cy.visit('http://localhost:8081/'); // Asegúrate de que sea la URL correcta

    cy.get('input[placeholder="Identificación"]').type('123456787788');
    cy.get('input[placeholder="Nombre de usuario"]').type('Usuario2');
    cy.get('input[placeholder="Contraseña"]').type('12345');
    cy.get('input[placeholder="Confirmar contraseña"]').type('12345');

    cy.contains('Registrarme').click();

    cy.contains('Usuario registrado correctamente').should('exist');
  });
});
