// jest.setup.js
import 'dotenv/config';