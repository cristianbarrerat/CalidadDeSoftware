import { supabase } from './lib/supabase'; // ajusta según tu proyecto
import bcrypt from 'bcryptjs';
import AsyncStorage from '@react-native-async-storage/async-storage';

type Deps = {
  supabaseInstance?: any;
  bcryptInstance?: any;
  AsyncStorageInstance?: any;
};

export async function loginUsuario(
  username: string,
  password: string,
  deps: Deps = {}
): Promise<{ success: boolean; message: string }> {
  const supabaseClient = deps.supabaseInstance || supabase;
  const bcryptLib = deps.bcryptInstance || bcrypt;
  const storage = deps.AsyncStorageInstance || AsyncStorage;

  if (!username || !password) {
    return { success: false, message: 'Campos requeridos' };
  }

  const { data: user, error } = await supabaseClient
    .from('users')
    .select('*')
    .eq('username', username)
    .single();

  if (error || !user) {
    return { success: false, message: 'Usuario no encontrado' };
  }

  const esValido = await bcryptLib.compare(password, user.password_hash);
  if (!esValido) {
    return { success: false, message: 'Contraseña incorrecta' };
  }

  await storage.setItem('usuario', JSON.stringify(user));
  return { success: true, message: 'Bienvenido' };
}
