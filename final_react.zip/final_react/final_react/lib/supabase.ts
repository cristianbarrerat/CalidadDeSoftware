import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://afumzcbpuwjeanhfxtld.supabase.co";
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFmdW16Y2JwdXdqZWFuaGZ4dGxkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgzODEyOTcsImV4cCI6MjA2Mzk1NzI5N30.BtTe_ijqOe442xh438Po7HoCmq_pZlJg9nenVLAIyLA";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
