export type EleccionesStackParamList = {
  EleccionesLista: undefined;
  EleccionForm: undefined | { id?: string };
};

export type RootStackParamList = {
  Resultados: { eleccionId: number };
  // otras pantallas
};
