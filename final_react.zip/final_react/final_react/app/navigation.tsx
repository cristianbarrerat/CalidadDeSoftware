import React, { useEffect, useState } from "react";
import { Platform, TouchableOpacity, Text } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";

import HomeScreen from "../screens/HomeScreen";
import ProfileScreen from "../screens/ProfileScreen";
import EleccionesScreen from "../screens/EleccionesScreen";
import CrearCandidaturaScreen from "../screens/CrearCandidaturaScreen";
import VotarScreen from "../screens/VotarScreen";
import ResultadosScreen from "../screens/ResultadosScreen";
import UserManagementScreen from "../screens/UserManagementScreen";
import EleccionesStack from "./EleccionesStack";
import { RootStackParamList } from "./types";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

// Define tipos para navegación (opcional)
export type RootTabParamList = {
  Inicio: undefined;
  Perfil: undefined;
  Elecciones: undefined;
  Candidaturas: undefined;
  Votar: undefined;
  Resultados: undefined;
  Usuarios: undefined;
};

const Tab = createBottomTabNavigator<RootTabParamList>();

export default function AppNavigation({ onLogout }: { onLogout: () => void }) {
  const [rol, setRol] = useState<string | null>(null);
  const Stack = createNativeStackNavigator<RootStackParamList>();

  useEffect(() => {
    const obtenerRol = async () => {
      let usuarioJSON: string | null = null;
      if (Platform.OS === "web") {
        usuarioJSON = localStorage.getItem("usuario");
      } else {
        usuarioJSON = await AsyncStorage.getItem("usuario");
      }
      if (usuarioJSON) {
        const usuario = JSON.parse(usuarioJSON);
        setRol(usuario.role);
      }
    };
    obtenerRol();
  }, []);

  const headerRight = () => (
    <TouchableOpacity
      onPress={async () => {
        const confirmar =
          Platform.OS === "web"
            ? window.confirm("¿Deseas salir de la aplicación?")
            : true;
        if (!confirmar) return;

        if (Platform.OS === "web") {
          localStorage.removeItem("usuario");
          window.location.reload();
        } else {
          await AsyncStorage.removeItem("usuario");
          onLogout();
        }
      }}
      style={{ marginRight: 15 }}
    >
      <Text style={{ color: "red", fontWeight: "bold" }}>Salir</Text>
    </TouchableOpacity>
  );

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerRight,
          tabBarIcon: ({ color, size }) => {
            let iconName: keyof typeof Ionicons.glyphMap = "help";
            switch (route.name) {
              case "Inicio":
                iconName = "home";
                break;
              case "Perfil":
                iconName = "person";
                break;
              case "Elecciones":
                iconName = "list";
                break;
              case "Candidaturas":
                iconName = "people-circle";
                break;
              case "Votar":
                iconName = "checkmark-circle";
                break;
              case "Resultados":
                iconName = "bar-chart";
                break;
              case "Usuarios":
                iconName = "people";
                break;
            }
            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen name="Inicio" component={HomeScreen} />
        <Tab.Screen name="Perfil" component={ProfileScreen} />
        <Tab.Screen name="Elecciones" component={EleccionesStack} />
        <Tab.Screen name="Candidaturas" component={CrearCandidaturaScreen} />
        <Tab.Screen name="Votar" component={VotarScreen} />
        <Tab.Screen name="Resultados" component={ResultadosScreen} />
        {rol === "ADMIN" && (
          <Tab.Screen name="Usuarios" component={UserManagementScreen} />
        )}
      </Tab.Navigator>
    </NavigationContainer>
  );
}
