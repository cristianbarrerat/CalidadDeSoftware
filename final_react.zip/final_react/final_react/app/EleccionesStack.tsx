import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import EleccionesLista from "../screens/EleccionesLista";
import EleccionForm from "../screens/EleccionesScreen";

const Stack = createNativeStackNavigator();

export default function EleccionesStack() {
  return (
    <Stack.Navigator initialRouteName="EleccionesLista">
      <Stack.Screen
        name="EleccionesLista"
        component={EleccionesLista}
        options={{ title: "Elecciones" }}
      />
      <Stack.Screen
        name="EleccionForm"
        component={EleccionForm}
        options={{ title: "Crear Elección" }}
      />
    </Stack.Navigator>
  );
}
