import { createClient } from "@supabase/supabase-js";
import bcrypt from "bcryptjs";

const supabaseUrl = "https://afumzcbpuwjeanhfxtld.supabase.co";
const supabaseAnonKey = process.env.SUPABASE_SECRET_KEY || "<TU_ANON_KEY>";
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function crearUsuarioAdmin(supabaseClient = supabase) {
  const username = "admin5";
  const identificacion = "123456789";
  const passwordPlano = "1234";
  const role = "ADMIN";

  const { data: existe, error: errorBusqueda } = await supabaseClient
    .from("users")
    .select("*")
    .eq("username", username)
    .single();

  if (existe) {
    console.log("⚠️ Ya existe un usuario con ese nombre.");
    return;
  }

  const passwordHash = await bcrypt.hash(passwordPlano, 10);

  const { error } = await supabaseClient.from("users").insert([
    {
      identificacion,
      username,
      password_hash: passwordHash,
      role,
    },
  ]);

  if (error) {
    console.error("❌ Error creando el usuario :", error.message);
  } else {
    console.log("✅ Usuario  creado exitosamente.");
  }
}
