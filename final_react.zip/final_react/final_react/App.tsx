import { useState, useEffect } from "react";
import { View, Text, StyleSheet, Platform } from "react-native";
import AppNavigation from "./app/navigation";
import LoginScreen from "./screens/LoginScreen";
import RegisterScreen from "./screens/RegisterScreen"; // si tienes pantalla de registro
import LandingPage from "./screens/LandingPage"; // importa tu landing page
import AsyncStorage from "@react-native-async-storage/async-storage";
import { VotacionProvider } from "./screens/VotacionContext";

export default function App() {
  const [logueado, setLogueado] = useState(false);
  const [mensajeLogout, setMensajeLogout] = useState("");
  const [vistaActual, setVistaActual] = useState<
    "landing" | "login" | "register"
  >("landing");

  useEffect(() => {
    const verificarSesion = async () => {
      if (Platform.OS === "web") {
        const usuario = localStorage.getItem("usuario");
        if (usuario) setLogueado(true);
      } else {
        const usuario = await AsyncStorage.getItem("usuario");
        if (usuario) setLogueado(true);
      }
    };
    verificarSesion();
  }, []);

  const cerrarSesion = () => {
    setLogueado(false);
    setVistaActual("landing");
    setMensajeLogout("🚪 Has cerrado sesión exitosamente");
    setTimeout(() => setMensajeLogout(""), 3000);
  };

  if (logueado) {
    return (
      <VotacionProvider>
        <AppNavigation onLogout={cerrarSesion} />
      </VotacionProvider>
    );
  }

  return (
    <VotacionProvider>
      <View style={{ flex: 1 }}>
        {mensajeLogout !== "" && (
          <View style={styles.flash}>
            <Text style={styles.flashText}>{mensajeLogout}</Text>
          </View>
        )}

        {vistaActual === "landing" && (
          <LandingPage
            onIniciarSesion={() => setVistaActual("login")}
            onRegistrarme={() => setVistaActual("register")}
          />
        )}

        {vistaActual === "login" && (
          <LoginScreen
            navigation={{
              replace: () => setLogueado(true),
              goBack: () => setVistaActual("landing"),
            }}
          />
        )}

        {vistaActual === "register" && (
          <RegisterScreen
            navigation={{
              replace: () => setLogueado(true),
              goBack: () => setVistaActual("landing"),
            }}
          />
        )}
      </View>
    </VotacionProvider>
  );
}

const styles = StyleSheet.create({
  flash: {
    backgroundColor: "#d4edda",
    padding: 10,
    borderRadius: 6,
    margin: 10,
    borderColor: "#c3e6cb",
    borderWidth: 1,
  },
  flashText: {
    color: "#155724",
    textAlign: "center",
    fontWeight: "bold",
  },
});
