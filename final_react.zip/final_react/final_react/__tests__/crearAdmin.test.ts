import { crearUsuarioAdmin } from '../scripts/crearAdmin';

import bcrypt from "bcryptjs";

jest.mock("bcryptjs", () => ({
  hash: jest.fn().mockResolvedValue("hashed_password"),
}));

describe("crearUsuarioAdmin", () => {
  const mockInsert = jest.fn();
  const mockSingle = jest.fn();

  // Mock del cliente supabase
  const supabaseMock = {
    from: jest.fn(() => ({
      select: jest.fn(() => ({
        eq: jest.fn(() => ({
          single: mockSingle,
        })),
      })),
      insert: mockInsert,
    })),
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("debería crear un usuario si no existe", async () => {
    mockSingle.mockResolvedValue({ data: null, error: null });
    mockInsert.mockResolvedValue({ error: null });

    const consoleSpy = jest.spyOn(console, "log").mockImplementation(() => {});

    await crearUsuarioAdmin(supabaseMock as any);

    expect(mockSingle).toHaveBeenCalled();
    expect(mockInsert).toHaveBeenCalled();
    expect(consoleSpy).toHaveBeenCalledWith("✅ Usuario  creado exitosamente.");

    consoleSpy.mockRestore();
  });

  it("no debería crear usuario si ya existe", async () => {
    mockSingle.mockResolvedValue({ data: { username: "admin5" }, error: null });

    const consoleSpy = jest.spyOn(console, "log").mockImplementation(() => {});

    await crearUsuarioAdmin(supabaseMock as any);

    expect(mockInsert).not.toHaveBeenCalled();
    expect(consoleSpy).toHaveBeenCalledWith("⚠️ Ya existe un usuario con ese nombre.");

    consoleSpy.mockRestore();
  });
});
