import { describe, it, expect } from 'vitest';
import { loginUsuario } from '../loginLogic';

// Mocks
const mockUser = {
  id: 'user1',
  username: 'usuario1',
  password_hash: 'hashedPassword',
};

const supabaseMock = {
  from: () => ({
    select: () => ({
      eq: () => ({
        single: async () => ({ data: mockUser, error: null }),
      }),
    }),
  }),
};

const supabaseMockFail = {
  from: () => ({
    select: () => ({
      eq: () => ({
        single: async () => ({ data: null, error: { message: 'No encontrado' } }),
      }),
    }),
  }),
};

const bcryptMock = {
  compare: async (password: string, hash: string) => password === 'correctPassword',
};

const bcryptMockFail = {
  compare: async () => false,
};

const AsyncStorageMock = {
  setItem: async (key: string, value: string) => Promise.resolve(),
};

describe('loginUsuario', () => {
  it('debe validar usuario y contraseña correctamente', async () => {
    const result = await loginUsuario('usuario1', 'correctPassword', {
      supabaseInstance: supabaseMock,
      bcryptInstance: bcryptMock,
      AsyncStorageInstance: AsyncStorageMock,
    });

    expect(result.success).toBe(true);
    expect(result.message).toBe('Bienvenido');
  });

  it('falla si usuario no existe', async () => {
    const result = await loginUsuario('noExiste', '1234', {
      supabaseInstance: supabaseMockFail,
      bcryptInstance: bcryptMock,
      AsyncStorageInstance: AsyncStorageMock,
    });

    expect(result.success).toBe(false);
    expect(result.message).toBe('Usuario no encontrado');
  });

  it('falla con contraseña incorrecta', async () => {
    const result = await loginUsuario('usuario1', 'wrongPassword', {
      supabaseInstance: supabaseMock,
      bcryptInstance: bcryptMockFail,
      AsyncStorageInstance: AsyncStorageMock,
    });

    expect(result.success).toBe(false);
    expect(result.message).toBe('Contraseña incorrecta');
  });
});
