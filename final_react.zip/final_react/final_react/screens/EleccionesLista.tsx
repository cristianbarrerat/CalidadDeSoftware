import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Button,
} from "react-native";
import { supabase } from "../lib/supabase";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { EleccionesStackParamList } from "../app/types";
import { useFocusEffect } from "@react-navigation/native";

type NavigationProp = NativeStackNavigationProp<EleccionesStackParamList>;

interface Eleccion {
  id: string;
  nombre: string;
  descripcion: string;
  tipo_representacion: string;
  fecha_inicio: string;
  fecha_fin: string;
  estado: string;
}

export default function EleccionesLista() {
  const [elecciones, setElecciones] = useState<Eleccion[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const navigation = useNavigation<NavigationProp>();

  useFocusEffect(
    useCallback(() => {
      fetchElecciones();
    }, [])
  );

  const fetchElecciones = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("eleccions")
      //.select("*")
      //.eq("estado", "activa") // si quieres solo activas, descomenta
      .select("*")
      .order("fecha_inicio", { ascending: true });

    if (error) {
      console.log("Error fetching elecciones:", error.message);
      setLoading(false);
      return;
    }

    setElecciones(data || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchElecciones();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchElecciones();
    setRefreshing(false);
  };

  const renderItem = ({ item }: { item: Eleccion }) => {
    const toggleEstado = async (id: string, estadoActual: string) => {
      try {
        let nuevoEstado: string;

        if (estadoActual === "activa") {
          nuevoEstado = "finalizada"; // o "programada" según tu lógica
        } else if (estadoActual === "programada") {
          nuevoEstado = "activa";
        } else {
          // Si está finalizada, quizás no puedas cambiar o definir otra lógica
          nuevoEstado = "activa"; // o lo que consideres
        }

        const { error } = await supabase
          .from("eleccions")
          .update({ estado: nuevoEstado })
          .eq("id", id);

        if (error) {
          alert("Error al cambiar el estado: " + error.message);
        } else {
          alert(`Estado cambiado a ${nuevoEstado}`);
          fetchElecciones(); // refresca la lista
        }
      } catch (e) {
        alert("Error inesperado");
      }
    };

    return (
      <View style={styles.itemContainer}>
        <Text style={styles.title}>{item.nombre}</Text>
        <Text>{item.descripcion}</Text>
        <Text>Tipo: {item.tipo_representacion}</Text>
        <Text>Estado: {item.estado}</Text>
        <Text>Desde: {new Date(item.fecha_inicio).toLocaleString()}</Text>
        <Text>Hasta: {new Date(item.fecha_fin).toLocaleString()}</Text>

        <View style={styles.buttonsRow}>
          <Button
            title={item.estado === "activa" ? "Finalizar" : "Activar"}
            onPress={() => toggleEstado(item.id, item.estado)}
          />

          <Button
            title="Editar"
            onPress={() => navigation.navigate("EleccionForm", { id: item.id })}
          />
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" />
      </View>
    );
  }
  return (
    <View style={styles.container}>
      <Button
        title="Crear Nueva Elección"
        onPress={() => navigation.navigate("EleccionForm")}
      />

      {elecciones.length === 0 ? (
        <Text>No hay elecciones disponibles.</Text>
      ) : (
        <FlatList
          data={elecciones}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  itemContainer: {
    backgroundColor: "#fafafa",
    borderRadius: 6,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  title: {
    fontWeight: "bold",
    fontSize: 16,
    marginBottom: 4,
  },
  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonsRow: {
    // <---- Agrega esto
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
});
