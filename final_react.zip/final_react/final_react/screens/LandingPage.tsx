import React from "react";
import { View, Text, StyleSheet, Button, ScrollView } from "react-native";

type Props = {
  onIniciarSesion: () => void;
  onRegistrarme: () => void;
};

export default function LandingPage({ onIniciarSesion, onRegistrarme }: Props) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Sistema de Votación USTA Tunja</Text>

      <Text style={styles.description}>
        Bienvenido al sistema oficial de votación de la Universidad Santo Tomás,
        sede Tunja.{"\n\n"}
        Aquí podrás participar en las elecciones de forma segura y transparente.
        Podrás votar, consultar resultados y seguir el proceso electoral con
        facilidad.{"\n\n"}
        ¡Tu voto es importante para construir una mejor universidad!
      </Text>

      <View style={styles.buttonContainer}>
        <Button title="Iniciar Sesión" onPress={onIniciarSesion} />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="Registrarme" onPress={onRegistrarme} color="#4CAF50" />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 30,
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
    color: "#2c3e50",
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: "center",
    marginBottom: 40,
    color: "#34495e",
  },
  buttonContainer: {
    width: "80%",
    marginVertical: 10,
  },
});
