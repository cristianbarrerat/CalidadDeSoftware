import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Alert,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { supabase } from "../lib/supabase";

export default function ProfileScreen() {
  const [nombres, setNombres] = useState("");
  const [apellidos, setApellidos] = useState("");
  const [edad, setEdad] = useState("");
  const [genero, setGenero] = useState("masculino");
  const [mensajeExito, setMensajeExito] = useState("");
  const [userId, setUserId] = useState<number | null>(null);
  const [perfilExistente, setPerfilExistente] = useState(false);

  const cargarUsuario = async () => {
    let local = null;
    if (Platform.OS === "web") {
      local = localStorage.getItem("usuario");
    } else {
      local = await AsyncStorage.getItem("usuario");
    }
    if (local) {
      const parsed = JSON.parse(local);
      setUserId(parsed.id);
    }
  };

  const cargarPerfil = async () => {
    if (!userId) return;
    const { data, error } = await supabase
      .from("userprofiles")
      .select("*")
      .eq("user_id", userId)
      .single();

    if (data) {
      setNombres(data.nombres);
      setApellidos(data.apellidos);
      setEdad(String(data.edad));
      setGenero(data.genero);
      setPerfilExistente(true);
    }
  };

  const guardarPerfil = async () => {
    if (!nombres || !apellidos || !edad || !genero || !userId) {
      Alert.alert("Campos incompletos", "Por favor completa todos los campos.");
      return;
    }

    const edadNum = parseInt(edad);
    if (isNaN(edadNum) || edadNum <= 0) {
      Alert.alert("Edad inválida", "Por favor ingresa una edad válida.");
      return;
    }

    const datos = {
      user_id: userId,
      nombres,
      apellidos,
      edad: edadNum,
      genero,
    };

    let error = null;

    if (perfilExistente) {
      ({ error } = await supabase
        .from("userprofiles")
        .update(datos)
        .eq("user_id", userId));
    } else {
      ({ error } = await supabase.from("userprofiles").insert([datos]));
    }

    if (error) {
      Alert.alert("Error", "No se pudo guardar el perfil");
    } else {
      setMensajeExito("✅ Perfil guardado correctamente.");
      setTimeout(() => setMensajeExito(""), 3000);
    }
  };

  useEffect(() => {
    cargarUsuario();
  }, []);

  useEffect(() => {
    if (userId) cargarPerfil();
  }, [userId]);

  const generos = [
    { label: "Masculino", value: "masculino" },
    { label: "Femenino", value: "femenino" },
    { label: "Otro", value: "otro" },
  ];

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <Text style={styles.title}>Perfil del Usuario</Text>

      {mensajeExito !== "" && (
        <View style={styles.flash}>
          <Text style={styles.flashText}>{mensajeExito}</Text>
        </View>
      )}

      <TextInput
        placeholder="Nombres"
        style={styles.input}
        value={nombres}
        onChangeText={setNombres}
      />

      <TextInput
        placeholder="Apellidos"
        style={styles.input}
        value={apellidos}
        onChangeText={setApellidos}
      />

      <TextInput
        placeholder="Edad"
        style={styles.input}
        value={edad}
        onChangeText={setEdad}
        keyboardType="numeric"
      />

      <Text style={styles.label}>Género:</Text>
      <View style={styles.generoContainer}>
        {generos.map((g) => (
          <TouchableOpacity
            key={g.value}
            style={[
              styles.generoBoton,
              genero === g.value && styles.generoBotonSeleccionado,
            ]}
            onPress={() => setGenero(g.value)}
          >
            <Text
              style={[
                styles.generoTexto,
                genero === g.value && styles.generoTextoSeleccionado,
              ]}
            >
              {g.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Button title="Guardar perfil" onPress={guardarPerfil} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f0f0f0" },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  input: {
    backgroundColor: "white",
    padding: 10,
    borderRadius: 8,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#ccc",
  },
  label: {
    marginBottom: 8,
    fontWeight: "bold",
    fontSize: 16,
  },
  generoContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 20,
  },
  generoBoton: {
    flex: 1,
    marginHorizontal: 5,
    paddingVertical: 12,
    backgroundColor: "white",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
  },
  generoBotonSeleccionado: {
    backgroundColor: "#007AFF",
    borderColor: "#005BB5",
  },
  generoTexto: {
    color: "#444",
    textAlign: "center",
    fontWeight: "500",
  },
  generoTextoSeleccionado: {
    color: "white",
  },
  flash: {
    backgroundColor: "#d1ecf1",
    padding: 10,
    borderRadius: 6,
    marginBottom: 15,
    borderColor: "#bee5eb",
    borderWidth: 1,
  },
  flashText: {
    color: "#0c5460",
    textAlign: "center",
    fontWeight: "500",
  },
});
