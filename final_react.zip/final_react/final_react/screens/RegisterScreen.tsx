import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Alert,
} from "react-native";
import { supabase } from "../lib/supabase";
import bcrypt from "bcryptjs";

type Props = {
  navigation: {
    replace: () => void;
    goBack: () => void;
  };
};

export default function RegisterScreen({ navigation }: Props) {
  const [identificacion, setIdentificacion] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [mensajeExito, setMensajeExito] = useState(""); // ✅ NUEVO

  const onRegister = async () => {
    if (!identificacion || !username || !password) {
      Alert.alert("Error", "Por favor llena todos los campos");
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert("Error", "Las contraseñas no coinciden");
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.from("users").insert([
        {
          identificacion,
          username,
          password_hash: password,
          role: "VOTANTE",
        },
      ]);

      if (error) {
        Alert.alert("Error", error.message);
        setLoading(false);
        return;
      }

      setMensajeExito("Usuario registrado correctamente"); // ✅ NUEVO
      Alert.alert("Éxito", "Usuario registrado correctamente");
      // navigation.replace(); // ❗ Comenta esto mientras haces el test
    } catch (err) {
      Alert.alert("Error", "Error desconocido al registrar");
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Registro de Usuario</Text>

      {mensajeExito !== "" && (
        <Text style={styles.successMessage}>{mensajeExito}</Text> // ✅ NUEVO
      )}

      <TextInput
        placeholder="Identificación"
        style={styles.input}
        value={identificacion}
        onChangeText={setIdentificacion}
      />

      <TextInput
        placeholder="Nombre de usuario"
        style={styles.input}
        value={username}
        onChangeText={setUsername}
        autoCapitalize="none"
      />

      <TextInput
        placeholder="Contraseña"
        style={styles.input}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      <TextInput
        placeholder="Confirmar contraseña"
        style={styles.input}
        value={confirmPassword}
        onChangeText={setConfirmPassword}
        secureTextEntry
      />

      <Button
        title={loading ? "Registrando..." : "Registrarme"}
        onPress={onRegister}
        disabled={loading}
      />

      <Button title="Volver" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 20 },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  input: {
    borderWidth: 1,
    borderColor: "#999",
    borderRadius: 6,
    padding: 10,
    marginBottom: 15,
  },
  successMessage: {
    color: "green",
    fontSize: 16,
    textAlign: "center",
    marginBottom: 20,
  },
});
