import React, { createContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "../lib/supabase";

export type Eleccion = {
  id: number;
  nombre: string;
  descripcion: string;
  tipo_representacion: "facultad" | "semestre" | "comite";
  fecha_inicio: string;
  fecha_fin: string;
  estado: "activa" | "finalizada" | "programada";
};

export type Candidatura = {
  id: number;
  propuesta: string;
  userId: number;
  eleccionId: number;
};

type VotacionContextType = {
  elecciones: Eleccion[];
  candidaturas: Candidatura[];
  cargarEleccionesActivas: () => Promise<void>;
  cargarCandidaturasPorEleccion: (eleccionId: number) => Promise<void>;
  emitirVoto: (
    userId: number,
    eleccionId: number,
    candidaturaId: number
  ) => Promise<boolean>;
};

export const VotacionContext = createContext<VotacionContextType>({
  elecciones: [],
  candidaturas: [],
  cargarEleccionesActivas: async () => {},
  cargarCandidaturasPorEleccion: async () => {},
  emitirVoto: async () => false,
});

export const VotacionProvider = ({ children }: { children: ReactNode }) => {
  const [elecciones, setElecciones] = useState<Eleccion[]>([]);
  const [candidaturas, setCandidaturas] = useState<Candidatura[]>([]);

  const cargarEleccionesActivas = async () => {
    const { data, error } = await supabase
      .from("eleccions")
      .select("*")
      .eq("estado", "activa")
      .order("fecha_inicio", { ascending: false });

    if (error) {
      console.error("Error cargando elecciones:", error);
      return;
    }

    setElecciones(data || []);
  };

  const cargarCandidaturasPorEleccion = async (eleccionId: number) => {
    const { data, error } = await supabase
      .from("candidaturas")
      .select("*")
      .eq("eleccionId", eleccionId);

    if (error) {
      console.error("Error cargando candidaturas:", error);
      return;
    }

    setCandidaturas(data || []);
  };

  const emitirVoto = async (
    userId: number,
    eleccionId: number,
    candidaturaId: number
  ) => {
    // Antes de votar, revisar si ya votó para esa elección
    const { data: votosExistentes, error: errorCheck } = await supabase
      .from("votos")
      .select("*")
      .eq("userId", userId)
      .eq("eleccionId", eleccionId);

    if (errorCheck) {
      console.error("Error verificando voto:", errorCheck);
      return false;
    }

    if (votosExistentes && votosExistentes.length > 0) {
      // Ya votó, no permite votar dos veces
      return false;
    }

    const { error } = await supabase.from("votos").insert([
      {
        userId,
        eleccionId,
        candidaturaId,
      },
    ]);

    if (error) {
      console.error("Error insertando voto:", error);
      return false;
    }

    return true;
  };

  useEffect(() => {
    cargarEleccionesActivas();
  }, []);

  return (
    <VotacionContext.Provider
      value={{
        elecciones,
        candidaturas,
        cargarEleccionesActivas,
        cargarCandidaturasPorEleccion,
        emitirVoto,
      }}
    >
      {children}
    </VotacionContext.Provider>
  );
};
