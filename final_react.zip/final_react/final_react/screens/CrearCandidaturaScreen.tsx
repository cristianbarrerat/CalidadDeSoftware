import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Alert,
  FlatList,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { supabase } from "../lib/supabase";

export default function CandidaturasScreen() {
  // Lista de elecciones
  const [elecciones, setElecciones] = useState<any[]>([]);
  // Elección seleccionada (id)
  const [eleccionSeleccionada, setEleccionSeleccionada] = useState<
    number | null
  >(null);

  // Candidaturas para la elección seleccionada
  const [candidaturas, setCandidaturas] = useState<any[]>([]);
  const [propuesta, setPropuesta] = useState("");
  const [loading, setLoading] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  // ID del usuario logueado
  const [userId, setUserId] = useState<number | null>(null);

  // Cargar usuario logueado de almacenamiento local
  const cargarUsuario = async () => {
    let localUser: string | null = null;
    if (Platform.OS === "web") {
      localUser = localStorage.getItem("usuario");
    } else {
      localUser = await AsyncStorage.getItem("usuario");
    }

    if (localUser) {
      try {
        const user = JSON.parse(localUser);
        setUserId(user.id);
      } catch (error) {
        console.error("Error parseando usuario:", error);
      }
    }
  };

  // Cargar elecciones desde supabase
  const cargarElecciones = async () => {
    const { data, error } = await supabase
      .from("eleccions")
      .select("*")
      .order("fecha_inicio", { ascending: false });

    if (error) {
      Alert.alert("Error", "No se pudieron cargar las elecciones.");
      return;
    }
    setElecciones(data || []);
  };

  // Cargar candidaturas filtrando por elección seleccionada
  const cargarCandidaturas = async (eleccionid: number) => {
    setLoading(true);
    const { data, error } = await supabase
      .from("candidaturas")
      .select("*")
      .eq("eleccionid", eleccionid)
      .order("createdat", { ascending: false });

    if (error) {
      console.error("Error cargando candidaturas:", error);
      Alert.alert("Error", "No se pudieron cargar las candidaturas.");
      setLoading(false);
      return;
    }
    setCandidaturas(data || []);
    setLoading(false);
  };

  // Carga inicial elecciones y usuario
  useEffect(() => {
    cargarElecciones();
    cargarUsuario();
  }, []);

  // Al cambiar elección seleccionada, cargar candidaturas y limpiar formulario
  useEffect(() => {
    if (eleccionSeleccionada !== null) {
      cargarCandidaturas(eleccionSeleccionada);
      setPropuesta("");
      setEditId(null);
    } else {
      setCandidaturas([]);
    }
  }, [eleccionSeleccionada]);

  // Crear o actualizar candidatura
  const guardarCandidatura = async () => {
    if (!eleccionSeleccionada) {
      Alert.alert("Error", "Por favor selecciona una elección.");
      return;
    }
    if (!propuesta.trim()) {
      Alert.alert("Error", "La propuesta no puede estar vacía.");
      return;
    }
    if (!userId) {
      Alert.alert("Error", "No se pudo identificar al usuario logueado.");
      return;
    }

    let error = null;
    if (editId === null) {
      // Crear nueva candidatura
      const { error: err } = await supabase.from("candidaturas").insert([
        {
          propuesta,
          eleccionid: eleccionSeleccionada,
          userid: userId, // <-- Aquí asignamos el userId
        },
      ]);
      error = err;
    } else {
      // Actualizar candidatura existente
      const { error: err } = await supabase
        .from("candidaturas")
        .update({ propuesta })
        .eq("id", editId);
      error = err;
    }

    if (error) {
      Alert.alert("Error", "No se pudo guardar la candidatura.");
    } else {
      Alert.alert(
        "Éxito",
        `Candidatura ${editId ? "actualizada" : "creada"} correctamente.`
      );
      setPropuesta("");
      setEditId(null);
      cargarCandidaturas(eleccionSeleccionada);
    }
  };

  // Cargar datos para editar candidatura
  const editar = (item: any) => {
    setPropuesta(item.propuesta);
    setEditId(item.id);
  };

  // Eliminar candidatura con confirmación
  const eliminar = async (id: number) => {
    Alert.alert(
      "Confirmar",
      "¿Seguro quieres eliminar esta candidatura?",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Eliminar",
          style: "destructive",
          onPress: async () => {
            const { error } = await supabase
              .from("candidaturas")
              .delete()
              .eq("id", id);
            if (error) {
              Alert.alert("Error", "No se pudo eliminar la candidatura.");
            } else {
              Alert.alert("Éxito", "Candidatura eliminada.");
              if (editId === id) {
                setPropuesta("");
                setEditId(null);
              }
              if (eleccionSeleccionada !== null)
                cargarCandidaturas(eleccionSeleccionada);
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  // Render item FlatList candidaturas
  const renderItem = ({ item }: { item: any }) => (
    <View style={styles.item}>
      <Text style={styles.propuestaText}>{item.propuesta}</Text>
      <View style={styles.buttonsContainer}>
        <Button title="Editar" onPress={() => editar(item)} />
        <Button
          title="Eliminar"
          color="#cc0000"
          onPress={() => eliminar(item.id)}
        />
      </View>
    </View>
  );

  // Render item FlatList elecciones con estilo card vertical
  const renderEleccionCard = ({ item }: { item: any }) => {
    const seleccionado = eleccionSeleccionada === item.id;
    return (
      <TouchableOpacity
        style={[
          styles.eleccionCard,
          seleccionado && styles.eleccionCardSeleccionada,
        ]}
        onPress={() => setEleccionSeleccionada(item.id)}
      >
        <Text style={styles.eleccionNombre}>{item.nombre}</Text>
        <Text style={styles.eleccionDescripcion}>{item.descripcion}</Text>
        <Text style={styles.eleccionFechas}>
          Inicio: {new Date(item.fecha_inicio).toLocaleDateString()}
        </Text>
        <Text style={styles.eleccionFechas}>
          Fin: {new Date(item.fecha_fin).toLocaleDateString()}
        </Text>
        <Text style={styles.eleccionEstado}>Estado: {item.estado}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <Text style={styles.title}>Selecciona una Elección</Text>

      <FlatList
        data={elecciones}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderEleccionCard}
        extraData={eleccionSeleccionada}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      <Text style={styles.title}>Crear / Editar Candidatura</Text>

      <TextInput
        style={styles.input}
        placeholder="Propuesta"
        value={propuesta}
        onChangeText={setPropuesta}
        multiline
      />

      <Button
        title={editId !== null ? "Actualizar Candidatura" : "Crear Candidatura"}
        onPress={guardarCandidatura}
      />

      <Text style={[styles.title, { marginTop: 30 }]}>
        Listado de Candidaturas
      </Text>

      {eleccionSeleccionada === null ? (
        <Text>Selecciona una elección para ver las candidaturas.</Text>
      ) : loading ? (
        <Text>Cargando candidaturas...</Text>
      ) : candidaturas.length === 0 ? (
        <Text>No hay candidaturas para esta elección.</Text>
      ) : (
        <FlatList
          data={candidaturas}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 50 }}
        />
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f9f9f9" },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },
  eleccionesContainer: {
    paddingVertical: 10,
    paddingHorizontal: 5,
  },
  eleccionCard: {
    backgroundColor: "white",
    borderRadius: 8,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#007AFF",
  },
  eleccionCardSeleccionada: {
    backgroundColor: "#007AFF",
  },
  eleccionNombre: {
    fontWeight: "bold",
    fontSize: 18,
    marginBottom: 5,
    color: "#000",
  },
  eleccionDescripcion: {
    fontSize: 14,
    marginBottom: 5,
    color: "#333",
  },
  eleccionFechas: {
    fontSize: 12,
    marginBottom: 2,
    color: "#555",
  },
  eleccionEstado: {
    fontSize: 12,
    fontWeight: "600",
    color: "#333",
  },
  eleccionTextoSeleccionado: {
    color: "white",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 10,
    borderRadius: 6,
    marginBottom: 15,
    backgroundColor: "white",
    minHeight: 60,
    textAlignVertical: "top",
  },
  item: {
    backgroundColor: "white",
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  propuestaText: {
    marginBottom: 10,
    fontSize: 16,
  },
  buttonsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
});
