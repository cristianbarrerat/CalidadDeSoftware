import { View, Text, StyleSheet, Button } from "react-native";
import { useNavigation } from "@react-navigation/native";

export default function HomeScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sistema de Votación</Text>
      <Text style={styles.subtitle}>USTA Tunja</Text>

      <View style={styles.buttonContainer}>
        <Button
          title="Ir a Votar"
          onPress={() => navigation.navigate("Votar" as never)}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title="Ver Resultados"
          onPress={() => navigation.navigate("Resultados" as never)}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title="Mi Perfil"
          onPress={() => navigation.navigate("Perfil" as never)}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
    backgroundColor: "#f5f5f5",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 8,
    color: "#2c3e50",
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 24,
    color: "#34495e",
  },
  buttonContainer: {
    width: "80%",
    marginVertical: 8,
  },
});
