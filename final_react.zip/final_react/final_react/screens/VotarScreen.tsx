import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Button,
  Alert,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from "react-native";
import { supabase } from "../lib/supabase";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function VotarScreen() {
  // Estado elecciones y selección
  const [elecciones, setElecciones] = useState<any[]>([]);
  const [eleccionSeleccionada, setEleccionSeleccionada] = useState<
    number | null
  >(null);

  // Estado candidatos y selección
  const [candidatos, setCandidatos] = useState<any[]>([]);
  const [candidatoSeleccionado, setCandidatoSeleccionado] = useState<
    number | null
  >(null);

  const [loadingCandidatos, setLoadingCandidatos] = useState(false);

  // Cargar elecciones desde supabase
  const cargarElecciones = async () => {
    const { data, error } = await supabase
      .from("eleccions")
      .select("*")
      .order("fecha_inicio", { ascending: false });

    if (error) {
      Alert.alert("Error", "No se pudieron cargar las elecciones.");
      return;
    }
    setElecciones(data || []);
  };

  // Cargar candidatos para elección seleccionada
  const cargarCandidatos = async (eleccionid: number) => {
    setLoadingCandidatos(true);
    // Traer candidaturas junto con info del usuario (relaciones)
    const { data, error } = await supabase
      .from("candidaturas")
      .select(`id, propuesta, userid`)
      .eq("eleccionid", eleccionid);

    if (error) {
      Alert.alert("Error", "No se pudieron cargar los candidatos.");
      setLoadingCandidatos(false);
      return;
    }
    setCandidatos(data || []);
    setLoadingCandidatos(false);
  };

  // Cargar elecciones y usuario al iniciar
  useEffect(() => {
    cargarElecciones();
  }, []);

  // Al cambiar elección, cargar candidatos y resetear selección
  useEffect(() => {
    if (eleccionSeleccionada !== null) {
      cargarCandidatos(eleccionSeleccionada);
      setCandidatoSeleccionado(null);
    } else {
      setCandidatos([]);
      setCandidatoSeleccionado(null);
    }
  }, [eleccionSeleccionada]);

  // Función para votar
  const votar = async () => {
    if (!eleccionSeleccionada) {
      Alert.alert("Error", "Selecciona una elección.");
      return;
    }
    if (!candidatoSeleccionado) {
      Alert.alert("Error", "Selecciona un candidato.");
      return;
    }

    // Obtener userId del votante (usuario logueado)
    let localUser: string | null = null;
    if (Platform.OS === "web") {
      localUser = localStorage.getItem("usuario");
    } else {
      localUser = await AsyncStorage.getItem("usuario");
    }
    if (!localUser) {
      Alert.alert("Error", "No se encontró usuario logueado.");
      return;
    }
    const user = JSON.parse(localUser);
    const userId = user.id;

    // Insertar voto en la tabla votos
    const { error } = await supabase.from("votos").insert([
      {
        userid: userId, // Ajusta si el campo en la tabla se llama distinto
        eleccionid: eleccionSeleccionada,
        candidaturaid: candidatoSeleccionado,
      },
    ]);

    if (error) {
      Alert.alert("Error", error.message || "No se pudo registrar el voto.");
    } else {
      Alert.alert("Éxito", "Voto registrado correctamente.");
      setCandidatoSeleccionado(null);
    }
  };

  // Render card para elegir elección
  const renderEleccionCard = ({ item }: { item: any }) => {
    const seleccionado = eleccionSeleccionada === item.id;
    return (
      <TouchableOpacity
        style={[
          styles.eleccionCard,
          seleccionado && styles.eleccionCardSeleccionada,
        ]}
        onPress={() => setEleccionSeleccionada(item.id)}
      >
        <Text style={styles.eleccionNombre}>{item.nombre}</Text>
        <Text style={styles.eleccionDescripcion}>{item.descripcion}</Text>
        <Text style={styles.eleccionFechas}>
          Inicio: {new Date(item.fecha_inicio).toLocaleDateString()}
        </Text>
        <Text style={styles.eleccionFechas}>
          Fin: {new Date(item.fecha_fin).toLocaleDateString()}
        </Text>
        <Text style={styles.eleccionEstado}>Estado: {item.estado}</Text>
      </TouchableOpacity>
    );
  };

  // Render card para candidato
  const renderCandidatoCard = ({ item }: { item: any }) => {
    const seleccionado = candidatoSeleccionado === item.id;
    const nombreCompleto = item.userprofiles
      ? `${item.userprofiles.nombres} ${item.userprofiles.apellidos}`
      : item.users
      ? item.users.username
      : "Candidato";

    return (
      <TouchableOpacity
        style={[
          styles.candidatoCard,
          seleccionado && styles.candidatoCardSeleccionado,
        ]}
        onPress={() => setCandidatoSeleccionado(item.id)}
      >
        <Text style={styles.candidatoNombre}>{nombreCompleto}</Text>
        <Text style={styles.candidatoPropuesta}>{item.propuesta}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <Text style={styles.title}>Selecciona una Elección</Text>

      <FlatList
        data={elecciones}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderEleccionCard}
        extraData={eleccionSeleccionada}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      <Text style={styles.title}>Selecciona un Candidato</Text>

      {loadingCandidatos ? (
        <Text>Cargando candidatos...</Text>
      ) : candidatos.length === 0 ? (
        <Text>No hay candidatos para esta elección.</Text>
      ) : (
        <FlatList
          data={candidatos}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderCandidatoCard}
          contentContainerStyle={{ paddingBottom: 50 }}
        />
      )}

      <Button title="Votar" onPress={votar} disabled={!candidatoSeleccionado} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f9f9f9" },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },
  eleccionCard: {
    backgroundColor: "white",
    borderRadius: 10,
    padding: 15,
    marginVertical: 8,
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: "#007AFF",
    elevation: 3,
  },
  eleccionCardSeleccionada: {
    backgroundColor: "#007AFF",
  },
  eleccionNombre: {
    fontWeight: "bold",
    fontSize: 18,
    marginBottom: 6,
    color: "#000",
  },
  eleccionDescripcion: {
    fontSize: 14,
    marginBottom: 6,
    color: "#444",
  },
  eleccionFechas: {
    fontSize: 12,
    color: "#666",
  },
  eleccionEstado: {
    fontSize: 12,
    fontWeight: "600",
    color: "#222",
    marginTop: 4,
  },
  candidatoCard: {
    backgroundColor: "white",
    borderRadius: 10,
    padding: 15,
    marginVertical: 6,
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: "#999",
    elevation: 2,
  },
  candidatoCardSeleccionado: {
    borderColor: "#007AFF",
    borderWidth: 2,
  },
  candidatoNombre: {
    fontWeight: "bold",
    fontSize: 16,
    marginBottom: 6,
  },
  candidatoPropuesta: {
    fontStyle: "italic",
    color: "#555",
  },
});
