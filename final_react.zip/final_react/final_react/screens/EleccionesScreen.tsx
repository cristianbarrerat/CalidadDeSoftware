import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Pressable,
  Alert,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Platform,
} from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { supabase } from "../lib/supabase";
import { Picker } from "@react-native-picker/picker";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { EleccionesStackParamList } from "../app/types";
import { useRoute, RouteProp } from "@react-navigation/native";

type NavigationProp = NativeStackNavigationProp<EleccionesStackParamList>;
type RouteProps = RouteProp<EleccionesStackParamList, "EleccionForm">;

export default function EleccionesScreen() {
  // Formulario estados
  const [nombre, setNombre] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [tipoRepresentacion, setTipoRepresentacion] = useState("");
  const [fechaInicio, setFechaInicio] = useState(new Date());
  const [fechaFin, setFechaFin] = useState(new Date());
  const [estado, setEstado] = useState("");
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<RouteProps>();
  const id = route.params?.id;
  const isEditMode = !!id;

  const [isInicioVisible, setInicioVisible] = useState(false);
  const [isFinVisible, setFinVisible] = useState(false);
  const [mensajeExito, setMensajeExito] = useState("");

  useEffect(() => {
    if (id) {
      // Consulta para cargar datos
      supabase
        .from("eleccions")
        .select("*")
        .eq("id", id)
        .single()
        .then(({ data, error }) => {
          if (error) {
            Alert.alert("Error", "No se pudo cargar la elección");
            return;
          }
          if (data) {
            setNombre(data.nombre);
            setDescripcion(data.descripcion);
            setTipoRepresentacion(data.tipo_representacion);
            setFechaInicio(new Date(data.fecha_inicio));
            setFechaFin(new Date(data.fecha_fin));
            setEstado(data.estado);
          }
        });
    }
  }, [id]);

  const handleSubmit = async () => {
    if (!nombre || !descripcion || !tipoRepresentacion || !estado) {
      Alert.alert("Error", "Por favor completa todos los campos.");
      return;
    }

    let error;
    if (id) {
      // Update
      const { error: updateError } = await supabase
        .from("eleccions")
        .update({
          nombre,
          descripcion,
          tipo_representacion: tipoRepresentacion,
          fecha_inicio: fechaInicio.toISOString(),
          fecha_fin: fechaFin.toISOString(),
          estado,
        })
        .eq("id", id);
      error = updateError;
    } else {
      // Insert
      const { error: insertError } = await supabase.from("eleccions").insert([
        {
          nombre,
          descripcion,
          tipo_representacion: tipoRepresentacion,
          fecha_inicio: fechaInicio.toISOString(),
          fecha_fin: fechaFin.toISOString(),
          estado,
        },
      ]);
      error = insertError;
    }

    if (error) {
      Alert.alert("Error", error.message);
    } else {
      Alert.alert(
        "Éxito",
        id
          ? "Elección actualizada correctamente"
          : "Elección creada correctamente"
      );
      navigation.goBack(); // regresa a la lista
    }
  };
  const tipos = [
    { label: "Facultad", value: "facultad" },
    { label: "Semestre", value: "semestre" },
    { label: "Comité", value: "comite" },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Crear Nueva Elección</Text>

      {mensajeExito !== "" && (
        <View style={styles.flash}>
          <Text style={styles.flashText}>{mensajeExito}</Text>
        </View>
      )}

      <TextInput
        style={styles.input}
        placeholder="Nombre"
        value={nombre}
        onChangeText={setNombre}
      />
      <TextInput
        style={[styles.input, { height: 80 }]}
        placeholder="Descripción"
        value={descripcion}
        onChangeText={setDescripcion}
        multiline
      />

      <Text style={styles.label}>Tipo de representación</Text>
      <View style={styles.tipoContainer}>
        {tipos.map((tipo) => (
          <TouchableOpacity
            key={tipo.value}
            style={[
              styles.tipoBoton,
              tipoRepresentacion === tipo.value && styles.tipoBotonSeleccionado,
            ]}
            onPress={() => setTipoRepresentacion(tipo.value)}
          >
            <Text
              style={[
                styles.tipoTexto,
                tipoRepresentacion === tipo.value &&
                  styles.tipoTextoSeleccionado,
              ]}
            >
              {tipo.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Fecha de inicio</Text>
      <Pressable onPress={() => setInicioVisible(true)}>
        <Text style={styles.dateText}>{fechaInicio.toLocaleString()}</Text>
      </Pressable>
      <DateTimePickerModal
        isVisible={isInicioVisible}
        mode="datetime"
        display="spinner"
        onConfirm={(date) => {
          setFechaInicio(date);
          setInicioVisible(false);
        }}
        onCancel={() => setInicioVisible(false)}
      />

      <Text style={styles.label}>Fecha de fin</Text>
      <Pressable onPress={() => setFinVisible(true)}>
        <Text style={styles.dateText}>{fechaFin.toLocaleString()}</Text>
      </Pressable>
      <DateTimePickerModal
        isVisible={isFinVisible}
        mode="datetime"
        display="spinner"
        onConfirm={(date) => {
          setFechaFin(date);
          setFinVisible(false);
        }}
        onCancel={() => setFinVisible(false)}
      />

      <Text style={styles.label}>Estado</Text>
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={estado}
          onValueChange={(itemValue) => setEstado(itemValue)}
          style={styles.picker}
        >
          <Picker.Item label="Seleccionar estado..." value="" />
          <Picker.Item label="Activa" value="activa" />
          <Picker.Item label="Finalizada" value="finalizada" />
          <Picker.Item label="Programada" value="programada" />
        </Picker>
      </View>

      <Button
        title={isEditMode ? "Editar Elección" : "Crear Elección"}
        onPress={handleSubmit}
      />

      <View style={{ marginTop: 10 }}>
        <Button
          title="Ver Elecciones"
          onPress={() => navigation.navigate("EleccionesLista")}
          color="#4CAF50"
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, paddingBottom: 100 },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },
  input: {
    borderWidth: 1,
    padding: 10,
    marginVertical: 8,
    borderRadius: 5,
  },
  label: { marginTop: 10, fontWeight: "bold" },
  tipoContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 8,
  },
  tipoBoton: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    paddingVertical: 10,
    marginHorizontal: 5,
    backgroundColor: "white",
  },
  tipoBotonSeleccionado: {
    backgroundColor: "#007AFF",
    borderColor: "#005BB5",
  },
  tipoTexto: {
    textAlign: "center",
    color: "#444",
    fontWeight: "500",
  },
  tipoTextoSeleccionado: {
    color: "white",
  },
  dateText: {
    borderWidth: 1,
    padding: 10,
    borderRadius: 5,
    marginVertical: 8,
    backgroundColor: "#eee",
  },
  flash: {
    backgroundColor: "#d4edda",
    padding: 10,
    borderRadius: 6,
    marginBottom: 15,
    borderColor: "#c3e6cb",
    borderWidth: 1,
  },
  flashText: {
    color: "#155724",
    textAlign: "center",
    fontWeight: "500",
  },
  eleccionItem: {
    backgroundColor: "#f8f9fa",
    padding: 15,
    borderRadius: 6,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  eleccionNombre: {
    fontWeight: "bold",
    fontSize: 16,
    marginBottom: 5,
  },
  pickerContainer: {
    // 👈 agrega esto
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    marginVertical: 8,
  },
  picker: {
    height: 50,
    width: "100%",
  },
});
