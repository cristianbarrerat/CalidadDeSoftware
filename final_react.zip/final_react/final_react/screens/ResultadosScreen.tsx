import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { supabase } from "../lib/supabase";
import { useFocusEffect } from "@react-navigation/native";
import { useCallback } from "react";

interface Resultado {
  eleccionid: number;
  eleccion_nombre: string;
  candidaturaid: number;
  candidatura_nombre: string;
  votos: number;
}

export default function ResultadosScreen() {
  const [resultados, setResultados] = useState<Resultado[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchResultados = async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc("votos_con_nombres");
    if (error) {
      console.error(error);
    } else {
      setResultados(data || []);
    }
    setLoading(false);
  };

  useFocusEffect(
    useCallback(() => {
      fetchResultados();
    }, [])
  );

  const resultadosPorEleccion = resultados.reduce(
    (acc: Record<string, Resultado[]>, curr) => {
      if (!acc[curr.eleccion_nombre]) {
        acc[curr.eleccion_nombre] = [];
      }
      acc[curr.eleccion_nombre].push(curr);
      return acc;
    },
    {}
  );

  const renderEleccion = (eleccionNombre: string) => (
    <View key={eleccionNombre} style={styles.eleccionContainer}>
      <Text style={styles.eleccionTitle}>Elección: {eleccionNombre}</Text>
      {resultadosPorEleccion[eleccionNombre].map((res) => (
        <View key={res.candidaturaid} style={styles.resultCard}>
          <Text>Candidatura: {res.candidatura_nombre}</Text>
          <Text>Votos: {res.votos}</Text>
        </View>
      ))}
    </View>
  );

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Resultados de todas las elecciones</Text>
      <FlatList
        data={Object.keys(resultadosPorEleccion)}
        keyExtractor={(item) => item}
        renderItem={({ item }) => renderEleccion(item)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, flex: 1 },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },
  eleccionContainer: {
    marginBottom: 20,
  },
  eleccionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  resultCard: {
    backgroundColor: "#f0f0f0",
    padding: 10,
    borderRadius: 8,
    marginBottom: 6,
  },
  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
