export const colors = {
    primary: '#3D5AFE',
    secondary: '#FF4081',
    background: '#F5F5F5',
    text: '#212121',
  };
  